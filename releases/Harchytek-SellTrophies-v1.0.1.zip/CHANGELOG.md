## v1.0.1
Added the `config` folder for downloading from the manager

## v1.0.0
Initial release