## v1.0.2
Updated to match the new website design and display changes.

## v1.0.1
Added the `config` folder for downloading from the manager

## v1.0.0
Initial release