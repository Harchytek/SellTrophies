# SellTrophies

Configuration library providing balanced selling prices for all Valheim trophies through the [TradersExtended](https://thunderstore.io/c/valheim/p/shudnal/TradersExtended/) mod. 

<p align="left"><img src="https://imgur.com/XzCrpCT.png" alt="SellTrophies" width="510"></p>

## Features

* **Configuration Library** : Contains a `JSON` list of all Valheim trophies.
* **Balanced Economy** : Prices scale naturally with biome difficulty and trophy rarity.
* **58 Trophies Included** : Complete coverage from Meadows to Ashlands.
* **Deep North Ready** : Future-proofed and updated as soon as the next biome drops.

*The Deep North trophies will be added later.*

This library was also created to complement [TrophyEater](https://thunderstore.io/c/valheim/p/Harchytek/TrophyEater/), drawing inspiration from the UsefulTrophies mod for players seeking a similar experience.

## Installation
1. Install [BepInExPack Valheim](https://valheim.thunderstore.io/package/denikson/BepInExPack_Valheim/) and [TradersExtended](https://thunderstore.io/c/valheim/p/shudnal/TradersExtended/).
2. Place `shudnal.TradersExtended` folder in your `BepInEx/config` folder.
3. Launch the game and you can sell the trophies to traders.

## About myself

If you have any suggestions or need help, you can contact me on Github.

I make these mods for my friends and me, but they can be useful to everyone. It's my way of contributing to the Valheim community.

<p align="left"><a href="https://github.com/Harchytek/SellTrophies/issues" target="_blank"><img src="https://cdn.simpleicons.org/github/C5C2FF" alt="Github" width="31" align="absmiddle"></a>&nbsp;<strong><a href="https://github.com/Harchytek?tab=repositories" target="_blank"> Harchytek</a></strong></p>