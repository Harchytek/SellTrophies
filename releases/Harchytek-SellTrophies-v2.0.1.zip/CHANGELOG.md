## v2.0.1
* Updated for Valheim 1.0 Deep North.

*Please delete the old file "shudnal.TradersExtended.common.sell.json".*

## v1.0.1
* Added the `config` folder for downloading from the manager

## v1.0.0
* Initial release